/*
 * cabinUpdate.h
 *
 *  Created on: Oct 22, 2023
 *      Author: Bhargav-4836
 */

#ifndef INC_CABINUPDATE_H_
#define INC_CABINUPDATE_H_





#endif /* INC_CABINUPDATE_H_ */


#include <WiFi.h>
#include <Update.h>


String getHeaderValue(String header, String headerName);

bool execOTA();
