/*
 * childLockControl.h
 *
 *  Created on: Oct 19, 2023
 *      Author: Bhargav-4836
 */

#ifndef INC_CHILDLOCKCONTROL_H_
#define INC_CHILDLOCKCONTROL_H_



#endif /* INC_CHILDLOCKCONTROL_H_ */


#include "main.h"
#include "usart.h"
#include "stdbool.h"



void checkChildLock();
void disableChildLock();
void enableChildLock();
