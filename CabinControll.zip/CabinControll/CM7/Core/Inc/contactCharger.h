/*
 * contactCharger.h
 *
 *  Created on: Oct 19, 2023
 *      Author: Bhargav-4836
 */

#ifndef INC_CONTACTCHARGER_H_
#define INC_CONTACTCHARGER_H_





#endif /* INC_CONTACTCHARGER_H_ */

#include "usart.h"

void initContactSenseOutput();
void toggleChargeIcon(int _State);

bool getCCstate();
